import java.io.File

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val signingKeystoreBase64 = System.getenv("SIGNING_KEYSTORE_BASE64")?.trim().orEmpty()
val signingKeystorePassword = System.getenv("SIGNING_KEYSTORE_PASSWORD").orEmpty()
val signingKeyAlias = System.getenv("SIGNING_KEY_ALIAS").orEmpty()
val signingKeyPassword = System.getenv("SIGNING_KEY_PASSWORD").orEmpty()
val hasSigningSecrets = signingKeystoreBase64.isNotEmpty() &&
    signingKeystorePassword.isNotEmpty() &&
    signingKeyAlias.isNotEmpty()

android {
    namespace = "com.salvia.salviabrowxer"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.salvia.salviabrowxer"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        if (hasSigningSecrets) {
            create("release") {
                val decodedFile = File(rootProject.layout.buildDirectory.asFile.get(), "release-keystore.jks")
                decodedFile.parentFile?.mkdirs()
                val cleaned = signingKeystoreBase64.replace("\\s".toRegex(), "")
                decodedFile.writeBytes(java.util.Base64.getDecoder().decode(cleaned))
                storeFile = decodedFile
                storePassword = signingKeystorePassword
                keyAlias = signingKeyAlias
                keyPassword = signingKeyPassword.ifEmpty { signingKeystorePassword }
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            if (hasSigningSecrets) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
        debug {
            applicationIdSuffix = ""
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        abortOnError = true
        warningsAsErrors = false
        baseline = file("lint-baseline.xml")
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    testImplementation("junit:junit:4.13.2")
}
